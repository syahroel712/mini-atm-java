/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BankSwing;

/**
 *
 * @author Syahrul 2101162018
 */
public class InformasiSaldoModel {
    private static InformasiSaldoModel instance;
    private int saldo;

    int deposit;
    int tarik;
    
    private InformasiSaldoModel() {
        saldo = 1000000;
    }
    
     public static InformasiSaldoModel getInstance() {
        if (instance == null) {
            instance = new InformasiSaldoModel();
        }
        return instance;
    }
    
    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getTarik() {
        return tarik;
    }

    void setTarik(int i) {
        saldo = saldo - i;
        System.out.println(saldo);
    }
    
    public int getDeposit() {
        return deposit;
    }

    public void setDeposit(int deposit) {
        saldo = saldo + deposit;
        System.out.println(saldo);
    }
}
